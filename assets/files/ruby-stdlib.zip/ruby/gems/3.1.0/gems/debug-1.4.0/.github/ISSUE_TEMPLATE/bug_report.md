---
name: Bug report
about: Create a report to help us improve
title: ''
labels: ''
assignees: ''

---

**Your environment**

* `ruby -v`: 
* `rdbg -v`:

**Describe the bug**
A clear and concise description of what the bug is.

**To Reproduce**

**Expected behavior**
A clear and concise description of what you expected to happen.

**Additional context**
Add any other context about the problem here.
