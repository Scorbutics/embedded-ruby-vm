# must never be extracted: its path escapes the install directory
